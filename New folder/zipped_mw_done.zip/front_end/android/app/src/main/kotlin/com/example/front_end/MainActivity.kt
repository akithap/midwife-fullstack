package com.example.front_end

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
